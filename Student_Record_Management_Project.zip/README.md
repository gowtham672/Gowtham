# Student Record Management System

This is a simple Python project for Class 12 CBSE Computer Science.

## Features
- Add student name, roll number, and grade.
- View all student records stored in a CSV file.

## Technologies Used
- Python
- CSV file handling

## How to Run
```bash
python student_record.py
```
